<?php



$connect = new PDO("mysql:host=localhost;dbname=assesment", "root", "");



?>


